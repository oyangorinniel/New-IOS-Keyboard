# iOS Style Keyboard (Android)

iOS-look keyboard with prediction bar, light/dark/system theme, height + one-handed adjustments,
key-click sounds + haptics, voice typing, and a tap-to-translate-to-English chip with automatic
language detection (ML Kit, on-device).

## Build with GitHub
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab -> **Build APK** -> *Run workflow* (it also runs on every push).
3. When it finishes, download the **ios-style-keyboard-apk** artifact and install `app-debug.apk`.
4. Open the app: 1) Enable keyboard, 2) Select keyboard, 3) Allow microphone.

## iOS key sounds
Apple's own sound files can't be redistributed. By default the keyboard uses Android's built-in
key sounds. To get the exact iOS feel, add your own licensed/recorded files:
`app/src/main/res/raw/key_click.wav`, `key_delete.wav`, `key_modifier.wav` (lowercase names).
They are picked up automatically.

## Notes
- Online predictions use Google's public suggest endpoint (unofficial, may change). Toggle in settings.
- Replace `app/src/main/assets/words_en.txt` with a larger frequency-ordered word list for better offline results.
- Translation language packs (~30 MB each) download the first time each language is used.
