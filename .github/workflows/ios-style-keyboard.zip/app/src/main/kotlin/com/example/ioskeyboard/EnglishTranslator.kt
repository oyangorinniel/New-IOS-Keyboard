package com.example.ioskeyboard

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/** On-device language detection + translation to English (ML Kit). Language packs download once. */
class EnglishTranslator {
    private val idClient = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.6f).build()
    )
    private val translators = HashMap<String, Translator>()

    fun detect(text: String, cb: (String) -> Unit) {
        idClient.identifyLanguage(text)
            .addOnSuccessListener { cb(it) }
            .addOnFailureListener { cb("und") }
    }

    fun translate(text: String, langTag: String, ok: (String) -> Unit, fail: () -> Unit) {
        val src = TranslateLanguage.fromLanguageTag(langTag)
        if (src == null) { fail(); return }
        val t = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.ENGLISH)
                    .build()
            )
        }
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                t.translate(text)
                    .addOnSuccessListener { ok(it) }
                    .addOnFailureListener { fail() }
            }
            .addOnFailureListener { fail() }
    }

    fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
        idClient.close()
    }
}
