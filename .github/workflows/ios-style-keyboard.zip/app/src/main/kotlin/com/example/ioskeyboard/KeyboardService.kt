package com.example.ioskeyboard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

private fun c(s: String) = Color.parseColor(s)

internal class Palette(
    val bg: Int, val key: Int, val special: Int, val keyDown: Int, val specialDown: Int,
    val text: Int, val shadow: Int, val accent: Int, val divider: Int
)

private val LIGHT = Palette(c("#D1D3D9"), c("#FFFFFF"), c("#ADB3BC"), c("#ADB3BC"), c("#FFFFFF"),
    c("#000000"), c("#898A8D"), c("#0A84FF"), c("#B0B3BA"))
private val DARK = Palette(c("#262628"), c("#6B6B6D"), c("#464648"), c("#464648"), c("#6B6B6D"),
    c("#FFFFFF"), c("#000000"), c("#0A84FF"), c("#555557"))

class KeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, NUMBERS, SYMBOLS }
    private enum class Shift { OFF, ON, CAPS }
    private enum class K { CHAR, SHIFT, DEL, NUM, SYM, ABC, GLOBE, SPACE, RETURN, GAP }
    private enum class Snd { CLICK, DEL, MOD }
    private class Key(val type: K, val label: String = "", val w: Float = 1f)

    private lateinit var prefs: Prefs
    private lateinit var engine: SuggestionEngine
    private val translator by lazy { EnglishTranslator() }
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var builtSig = ""
    private var root: View? = null
    private lateinit var pal: Palette
    private lateinit var keysContainer: LinearLayout
    private lateinit var sugViews: Array<TextView>
    private lateinit var dividers: Array<View>
    private lateinit var translateChip: TextView
    private lateinit var micBtn: TextView
    private var shiftView: TextView? = null
    private val letterViews = ArrayList<TextView>()

    private var mode = Mode.LETTERS
    private var shift = Shift.OFF
    private var lastSpace = 0L
    private var lastShiftTap = 0L
    private var suggestToken = 0
    private var cloudJob: Runnable? = null
    private var detectedLang: String? = null

    private var listening = false
    private var recognizer: SpeechRecognizer? = null

    private var pool: SoundPool? = null
    private val soundIds = HashMap<Snd, Int>()

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        engine = SuggestionEngine(this)
        initSounds()
    }

    override fun onCreateInputView(): View = buildView()

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (root == null || !::keysContainer.isInitialized || builtSig != prefs.signature()) {
            setInputView(buildView())
        }
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) Mode.NUMBERS else Mode.LETTERS
        shift = Shift.OFF
        rebuildKeys()
        showTranslate(null)
        scheduleRefresh()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopVoice()
        engine.save()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        scheduleRefresh()
    }

    override fun onDestroy() {
        stopVoice()
        engine.save()
        pool?.release()
        io.shutdownNow()
        translator.close()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI building

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun buildView(): View {
        builtSig = prefs.signature()
        pal = if (prefs.isDark()) DARK else LIGHT
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }
        outer.addView(buildBar(), LinearLayout.LayoutParams(-1, dp(44)))
        val kc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val side = (resources.displayMetrics.widthPixels * 0.2f).toInt()
        when (prefs.oneHanded) {
            "left" -> kc.setPadding(dp(3), 0, side, dp(6))
            "right" -> kc.setPadding(side, 0, dp(3), dp(6))
            else -> kc.setPadding(dp(3), 0, dp(3), dp(6))
        }
        keysContainer = kc
        outer.addView(kc, LinearLayout.LayoutParams(-1, -2))
        root = outer
        rebuildKeys()
        return outer
    }

    private fun buildBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        translateChip = TextView(this).apply {
            visibility = View.GONE
            textSize = 14f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply { setColor(pal.accent); cornerRadius = dp(16).toFloat() }
            setOnClickListener { doTranslate() }
        }
        bar.addView(translateChip, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(6), 0, dp(4), 0) })

        sugViews = Array(3) {
            TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 17f
                setTextColor(pal.text)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setOnClickListener { applySuggestion(text.toString()) }
            }
        }
        dividers = Array(2) { View(this).apply { setBackgroundColor(pal.divider) } }

        bar.addView(sugViews[0], LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(dividers[0], LinearLayout.LayoutParams(dp(1), dp(22)))
        bar.addView(sugViews[1], LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(dividers[1], LinearLayout.LayoutParams(dp(1), dp(22)))
        bar.addView(sugViews[2], LinearLayout.LayoutParams(0, -1, 1f))

        micBtn = TextView(this).apply {
            text = "🎤"
            textSize = 20f
            gravity = Gravity.CENTER
            setOnClickListener { toggleVoice() }
        }
        bar.addView(micBtn, LinearLayout.LayoutParams(dp(52), -1))
        return bar
    }

    private fun chars(s: String, w: Float = 1f) = s.map { Key(K.CHAR, it.toString(), w) }

    private fun bottom(first: Key) = listOf(
        first, Key(K.GLOBE, "", 1.2f), Key(K.SPACE, "space", 5.4f), Key(K.RETURN, "return", 2f)
    )

    private fun layoutFor(m: Mode): List<List<Key>> = when (m) {
        Mode.LETTERS -> listOf(
            chars("qwertyuiop"),
            listOf(Key(K.GAP, "", 0.5f)) + chars("asdfghjkl") + Key(K.GAP, "", 0.5f),
            listOf(Key(K.SHIFT, "", 1.4f)) + chars("zxcvbnm") + Key(K.DEL, "", 1.4f),
            bottom(Key(K.NUM, "123", 1.4f))
        )
        Mode.NUMBERS -> listOf(
            chars("1234567890"),
            chars("-/:;()$&@\""),
            listOf(Key(K.SYM, "#+=", 1.4f)) + chars(".,?!'", 1.4f) + Key(K.DEL, "", 1.4f),
            bottom(Key(K.ABC, "ABC", 1.4f))
        )
        Mode.SYMBOLS -> listOf(
            chars("[]{}#%^*+="),
            chars("_\\|~<>€£¥•"),
            listOf(Key(K.NUM, "123", 1.4f)) + chars(".,?!'", 1.4f) + Key(K.DEL, "", 1.4f),
            bottom(Key(K.ABC, "ABC", 1.4f))
        )
    }

    private fun rebuildKeys() {
        val kc = keysContainer
        kc.removeAllViews()
        letterViews.clear()
        shiftView = null
        val rowH = dp((54 * prefs.heightPct / 100f).roundToInt())
        for (row in layoutFor(mode)) {
            val ll = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in row) {
                if (k.type == K.GAP) {
                    ll.addView(View(this), LinearLayout.LayoutParams(0, -1, k.w))
                } else {
                    ll.addView(makeKey(k), LinearLayout.LayoutParams(0, -1, k.w).apply {
                        setMargins(dp(3), dp(5), dp(3), dp(5))
                    })
                }
            }
            kc.addView(ll, LinearLayout.LayoutParams(-1, rowH))
        }
    }

    private fun layer(color: Int): LayerDrawable {
        val r = dp(5).toFloat()
        val s = GradientDrawable().apply { setColor(pal.shadow); cornerRadius = r }
        val f = GradientDrawable().apply { setColor(color); cornerRadius = r }
        return LayerDrawable(arrayOf(s, f)).apply { setLayerInset(1, 0, 0, 0, dp(1)) }
    }

    private fun keyBg(special: Boolean, active: Boolean = false): StateListDrawable {
        val base = if (active) Color.WHITE else if (special) pal.special else pal.key
        val down = if (active) Color.WHITE else if (special) pal.specialDown else pal.keyDown
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), layer(down))
            addState(intArrayOf(), layer(base))
        }
    }

    private fun shiftGlyph() = when (shift) { Shift.OFF -> "⇧"; Shift.ON -> "⬆"; Shift.CAPS -> "⇪" }

    private fun makeKey(k: Key): TextView {
        val special = k.type != K.CHAR && k.type != K.SPACE
        val tv = TextView(this)
        tv.gravity = Gravity.CENTER
        tv.setTextColor(pal.text)
        tv.textSize = when (k.type) {
            K.CHAR -> 24f
            K.SHIFT, K.DEL -> 20f
            K.GLOBE -> 18f
            else -> 16f
        }
        tv.text = when (k.type) {
            K.CHAR -> if (mode == Mode.LETTERS && shift != Shift.OFF) k.label.uppercase() else k.label
            K.SHIFT -> shiftGlyph()
            K.DEL -> "⌫"
            K.GLOBE -> "🌐"
            else -> k.label
        }
        tv.background = keyBg(special)
        if (mode == Mode.LETTERS && k.type == K.CHAR) letterViews.add(tv)
        if (k.type == K.SHIFT) { shiftView = tv; styleShift() }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; onKey(k, tv) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; stopRepeat() }
            }
            true
        }
        return tv
    }

    private fun styleShift() {
        shiftView?.let {
            val active = shift != Shift.OFF
            it.text = shiftGlyph()
            it.background = keyBg(true, active)
            it.setTextColor(if (active) Color.BLACK else pal.text)
        }
    }

    private fun updateLetters() {
        for (v in letterViews) {
            val t = v.text.toString()
            v.text = if (shift != Shift.OFF) t.uppercase() else t.lowercase()
        }
        styleShift()
    }

    // ---------------------------------------------------------------- key handling

    private fun onKey(k: Key, v: View) {
        when (k.type) {
            K.CHAR -> { sound(Snd.CLICK, v); typeChar((v as TextView).text.toString()) }
            K.DEL -> { sound(Snd.DEL, v); deleteOnce(); handler.postDelayed(repeatRunnable, 400) }
            K.SHIFT -> { sound(Snd.MOD, v); toggleShift() }
            K.NUM -> { sound(Snd.MOD, v); switchMode(Mode.NUMBERS) }
            K.SYM -> { sound(Snd.MOD, v); switchMode(Mode.SYMBOLS) }
            K.ABC -> { sound(Snd.MOD, v); switchMode(Mode.LETTERS) }
            K.GLOBE -> { sound(Snd.MOD, v); switchKeyboard() }
            K.SPACE -> { sound(Snd.MOD, v); typeSpace() }
            K.RETURN -> { sound(Snd.MOD, v); pressReturn() }
            K.GAP -> {}
        }
    }

    private fun switchMode(m: Mode) {
        mode = m
        handler.post { rebuildKeys() }
    }

    private fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            now - lastShiftTap < 400 -> Shift.CAPS
            shift == Shift.OFF -> Shift.ON
            else -> Shift.OFF
        }
        lastShiftTap = now
        updateLetters()
    }

    private fun typeChar(s: String) {
        val ic = currentInputConnection ?: return
        if (!s[0].isLetter() && s != "'" && s != "’") learnCurrent()
        ic.commitText(s, 1)
        if (shift == Shift.ON) { shift = Shift.OFF; updateLetters() }
        scheduleRefresh()
    }

    private fun typeSpace() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (now - lastSpace < 450 && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
        } else {
            learnCurrent()
            ic.commitText(" ", 1)
        }
        lastSpace = now
        if (mode == Mode.NUMBERS) switchMode(Mode.LETTERS)
        scheduleRefresh()
    }

    private fun pressReturn() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        learnCurrent()
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        scheduleRefresh()
    }

    private fun deleteOnce() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        scheduleRefresh()
    }

    private val repeatRunnable = object : Runnable {
        override fun run() {
            deleteOnce()
            handler.postDelayed(this, 55)
        }
    }

    private fun stopRepeat() = handler.removeCallbacks(repeatRunnable)

    @Suppress("DEPRECATION")
    private fun switchKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val token = window?.window?.attributes?.token
        if (token == null || !imm.switchToNextInputMethod(token, false)) imm.showInputMethodPicker()
    }

    // ---------------------------------------------------------------- sound + haptics

    private fun initSounds() {
        val p = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        mapOf(Snd.CLICK to "key_click", Snd.DEL to "key_delete", Snd.MOD to "key_modifier").forEach { (s, n) ->
            val id = resources.getIdentifier(n, "raw", packageName)
            if (id != 0) soundIds[s] = p.load(this, id, 1)
        }
        pool = p
    }

    private fun sound(s: Snd, v: View) {
        if (prefs.haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (!prefs.sound) return
        val id = soundIds[s]
        if (id != null) { pool?.play(id, 1f, 1f, 1, 0, 1f); return }
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.playSoundEffect(
            when (s) {
                Snd.CLICK -> AudioManager.FX_KEYPRESS_STANDARD
                Snd.DEL -> AudioManager.FX_KEYPRESS_DELETE
                Snd.MOD -> AudioManager.FX_KEYPRESS_SPACEBAR
            }
        )
    }

    // ---------------------------------------------------------------- suggestions

    private fun isPasswordField(): Boolean {
        val t = currentInputEditorInfo?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    private val refreshRunnable = Runnable { autoCap(); updateSuggestions(); detectLanguage() }

    private fun scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 40)
    }

    private fun autoCap() {
        if (!prefs.autoCap || shift == Shift.CAPS || mode != Mode.LETTERS) return
        val ei = currentInputEditorInfo ?: return
        val caps = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        val want = if (caps != 0) Shift.ON else Shift.OFF
        if (want != shift) { shift = want; updateLetters() }
    }

    private fun wordContext(): Triple<String, String?, String> {
        val before = currentInputConnection?.getTextBeforeCursor(60, 0)?.toString() ?: ""
        val prefix = Regex("[\\p{L}'’]+$").find(before)?.value ?: ""
        val rest = before.substring(0, before.length - prefix.length)
        val prev = Regex("([\\p{L}'’]+)\\s*$").find(rest)?.groupValues?.get(1)
        return Triple(prefix, prev, before)
    }

    private fun learnCurrent() {
        if (isPasswordField()) return
        val (prefix, prev, _) = wordContext()
        if (prefix.length >= 2) engine.learn(prev, prefix)
    }

    private fun setSuggestions(list: List<String>, prefix: String) {
        if (!::sugViews.isInitialized) return
        val capFirst = prefix.firstOrNull()?.isUpperCase() == true || (prefix.isEmpty() && shift != Shift.OFF)
        for (i in 0 until 3) {
            var w = list.getOrNull(i) ?: ""
            if (w.isNotEmpty() && (w == "i" || w.startsWith("i'") || capFirst)) {
                w = w.replaceFirstChar { it.uppercase() }
            }
            sugViews[i].text = w
        }
    }

    private fun updateSuggestions() {
        if (!::sugViews.isInitialized) return
        if (isPasswordField()) { setSuggestions(emptyList(), ""); return }
        val (prefix, prev, before) = wordContext()
        val offline = engine.suggest(prev, prefix)
        setSuggestions(offline, prefix)

        cloudJob?.let { handler.removeCallbacks(it) }
        val token = ++suggestToken
        if (!prefs.cloud || before.isBlank() || !CloudSuggest.online(this)) return
        val ctxWords = before.trim().split(Regex("\\s+")).takeLast(3).joinToString(" ")
        val endsSpace = before.endsWith(" ")
        val job = Runnable {
            io.execute {
                if (token != suggestToken) return@execute
                val res = CloudSuggest.fetch(ctxWords, endsSpace)
                handler.post {
                    if (token == suggestToken && res.isNotEmpty()) {
                        val merged = (res.filter { !it.equals(prefix, true) } + offline).distinct().take(3)
                        setSuggestions(merged, prefix)
                    }
                }
            }
        }
        cloudJob = job
        handler.postDelayed(job, 120)
    }

    private fun applySuggestion(word: String) {
        if (word.isEmpty()) return
        val ic = currentInputConnection ?: return
        val (prefix, prev, _) = wordContext()
        ic.beginBatchEdit()
        ic.deleteSurroundingText(prefix.length, 0)
        ic.commitText("$word ", 1)
        ic.endBatchEdit()
        if (!isPasswordField()) engine.learn(prev, word)
        scheduleRefresh()
    }

    // ---------------------------------------------------------------- translate to English

    private fun detectLanguage() {
        val ic = currentInputConnection ?: return
        if (isPasswordField()) { showTranslate(null); return }
        val txt = ((ic.getTextBeforeCursor(500, 0) ?: "").toString() + (ic.getTextAfterCursor(500, 0) ?: "")).trim()
        if (txt.length < 12) { showTranslate(null); return }
        translator.detect(txt) { code ->
            val base = code.substringBefore('-')
            if (base == "und" || base == "en") showTranslate(null) else showTranslate(base)
        }
    }

    private fun showTranslate(code: String?) {
        detectedLang = code
        if (!::translateChip.isInitialized) return
        if (code == null) {
            translateChip.visibility = View.GONE
            sugViews[2].visibility = View.VISIBLE
            dividers[1].visibility = View.VISIBLE
        } else {
            val name = Locale.forLanguageTag(code).getDisplayLanguage(Locale.ENGLISH)
            translateChip.text = "🌐 $name → English"
            translateChip.visibility = View.VISIBLE
            sugViews[2].visibility = View.GONE
            dividers[1].visibility = View.GONE
        }
    }

    private fun doTranslate() {
        val code = detectedLang ?: return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(2000, 0)?.toString() ?: ""
        val after = ic.getTextAfterCursor(2000, 0)?.toString() ?: ""
        if ((before + after).isBlank()) return
        translateChip.text = "Translating…"
        translator.translate(before + after, code, { out ->
            currentInputConnection?.let {
                it.beginBatchEdit()
                it.deleteSurroundingText(before.length, after.length)
                it.commitText(out, 1)
                it.endBatchEdit()
            }
            showTranslate(null)
            scheduleRefresh()
        }, {
            Toast.makeText(
                this, "Couldn't translate. Connect to the internet once to download the language pack.",
                Toast.LENGTH_LONG
            ).show()
            showTranslate(code)
        })
    }

    // ---------------------------------------------------------------- voice typing

    private fun styleMic() {
        if (::micBtn.isInitialized) micBtn.text = if (listening) "🔴" else "🎤"
    }

    private fun toggleVoice() { if (listening) stopVoice() else startVoice() }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Allow microphone access to use voice typing", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(this, SettingsActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("ask_mic", true)
            )
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "No speech recognition service on this device", Toast.LENGTH_LONG).show()
            return
        }
        listening = true
        styleMic()
        beginRecognition()
    }

    private fun beginRecognition() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { stopVoice() }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) currentInputConnection?.setComposingText(t, 1)
            }
            override fun onResults(results: Bundle?) {
                var t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (!t.isNullOrBlank()) {
                    val ei = currentInputEditorInfo
                    val cap = ei != null && (currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0) != 0
                    if (cap) t = t.replaceFirstChar { it.uppercase() }
                    currentInputConnection?.commitText("$t ", 1)
                }
                scheduleRefresh()
                if (listening) handler.post { beginRecognition() }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            if (prefs.voiceLang.isNotEmpty()) putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.voiceLang)
        }
        r.startListening(i)
    }

    private fun stopVoice() {
        val wasListening = listening
        listening = false
        recognizer?.destroy()
        recognizer = null
        if (wasListening) currentInputConnection?.finishComposingText()
        styleMic()
    }
}
