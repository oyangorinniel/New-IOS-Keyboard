package com.example.ioskeyboard

import android.content.Context
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray

/** Offline predictor: built-in word list + words and word pairs learned from the user. */
class SuggestionEngine(ctx: Context) {
    private val words = ArrayList<String>()
    private val uni = HashMap<String, Int>()
    private val bi = HashMap<String, Int>()
    private val sp = ctx.getSharedPreferences("userdict", Context.MODE_PRIVATE)
    private var dirty = 0

    init {
        try {
            ctx.assets.open("words_en.txt").bufferedReader().use { r: BufferedReader ->
                r.forEachLine { line ->
                    val t = line.trim()
                    if (t.isNotEmpty()) words.add(t)
                }
            }
        } catch (_: Exception) {
        }
        parse(sp.getString("uni", "") ?: "", uni)
        parse(sp.getString("bi", "") ?: "", bi)
    }

    private fun parse(s: String, into: HashMap<String, Int>) {
        for (line in s.split('\n')) {
            val i = line.lastIndexOf('\t')
            if (i > 0) line.substring(i + 1).toIntOrNull()?.let { into[line.substring(0, i)] = it }
        }
    }

    private fun dump(m: Map<String, Int>) = m.entries.joinToString("\n") { "${it.key}\t${it.value}" }

    private fun prune(m: HashMap<String, Int>) {
        if (m.size > 6000) {
            val keep = m.entries.sortedByDescending { it.value }.take(4000).map { it.key }.toSet()
            m.keys.retainAll(keep)
        }
    }

    fun save() {
        if (dirty == 0) return
        prune(uni); prune(bi)
        sp.edit().putString("uni", dump(uni)).putString("bi", dump(bi)).apply()
        dirty = 0
    }

    fun learn(prev: String?, word: String) {
        val w = word.lowercase()
        if (w.length < 2) return
        uni[w] = (uni[w] ?: 0) + 1
        if (prev != null) {
            val k = prev.lowercase() + " " + w
            bi[k] = (bi[k] ?: 0) + 1
        }
        if (++dirty >= 5) save()
    }

    fun suggest(prev: String?, prefix: String): List<String> {
        val p = prefix.lowercase()
        val pv = prev?.lowercase()
        val scores = HashMap<String, Double>()
        fun add(w: String, s: Double) { scores[w] = (scores[w] ?: 0.0) + s }

        if (p.isEmpty()) {
            if (pv != null) {
                for ((k, c) in bi) if (k.startsWith("$pv ")) add(k.substring(pv.length + 1), c * 200.0)
            }
            for (i in 0 until minOf(40, words.size)) add(words[i], 40.0 - i)
        } else {
            for ((i, w) in words.withIndex()) if (w.startsWith(p) && w != p) add(w, 1000.0 - minOf(i, 900))
            for ((w, c) in uni) if (w.startsWith(p) && w != p) add(w, c * 60.0)
            if (pv != null) {
                for ((k, c) in bi) if (k.startsWith("$pv ")) {
                    val w = k.substring(pv.length + 1)
                    if (w.startsWith(p) && w != p) add(w, c * 200.0)
                }
            }
            if (scores.size < 3 && p.length >= 3) {
                for (w in words) if (withinOne(w, p) && w != p) add(w, 300.0)
            }
        }
        return scores.entries.sortedByDescending { it.value }.take(3).map { it.key }
    }

    private fun withinOne(a: String, b: String): Boolean {
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        var i = 0
        var j = 0
        var edits = 0
        while (i < a.length && j < b.length) {
            if (a[i] == b[j]) { i++; j++ } else {
                if (++edits > 1) return false
                when {
                    a.length > b.length -> i++
                    a.length < b.length -> j++
                    else -> { i++; j++ }
                }
            }
        }
        return edits + (a.length - i) + (b.length - j) <= 1
    }
}

/** Online predictor (Google's public suggest endpoint). Only the last ~3 typed words are sent. */
object CloudSuggest {
    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)
            ?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    fun fetch(context: String, endsWithSpace: Boolean): List<String> {
        return try {
            val q = if (endsWithSpace) "$context " else context
            val url = URL(
                "https://suggestqueries.google.com/complete/search?client=firefox&q=" +
                    URLEncoder.encode(q, "UTF-8")
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 1200
            c.readTimeout = 1200
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val arr = JSONArray(body).getJSONArray(1)
            val n = context.trim().split(Regex("\\s+")).size
            val idx = if (endsWithSpace) n else n - 1
            val out = LinkedHashSet<String>()
            for (i in 0 until arr.length()) {
                val toks = arr.getString(i).split(Regex("\\s+"))
                if (idx < toks.size && toks[idx].isNotBlank()) out.add(toks[idx])
            }
            out.toList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
